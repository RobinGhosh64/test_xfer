export interface User {
    name?: string;
    principleName?: string;
    jobTitle?: string;
    companyName?: string;
    department?: string;
    userType?: string;
    roleAssigned?: string;
    website?: string;
    mail?: string;
    contactNumber?: string;
    address?: string;
}

    